# YHZ — S&P submission source (double-anonymous build)

Entry point: `main_content_sp27.tex` — the only file in the bundle that carries
`\documentclass`. It defines the anonymous-submission switches and the document
skeleton, so there is no second top-level file to pick by accident.
Build (run from the directory that holds these files):

    pdflatex main_content_sp27.tex
    pdflatex main_content_sp27.tex

Result: 18 pages, US Letter, IEEEtran conference class, pdflatex (no bibtex run needed).

Anonymous build: `\AnonymousSubmission` is defined, so the author block, the ORCID
link, and reference [1] (the prior ESWA paper) render anonymously. Do not remove
that switch before submission.

## Layout
| file | role |
|---|---|
| `main_content_sp27.tex` | S&P entry point: document class, anonymous + appendix-inclusive switches, body order |
| `main_preamble.tex` | document class, packages, spacing |
| `main_frontmatter.tex` | `\begin{document}`, title, author block, abstract |
| `main_body.tex` | section order |
| `main_sections/` | the 13 body sections |
| `appendix_sp27.tex` | the 5-page submission appendix (paper + supporting appendices) |
| `appendix_shared.tex` | appendix tables shared with the arXiv build |
| `submission_references.tex` -> `main_references.tex` | bibliography |
| `macros.tex` | macros and colours |
| `figures/` | TikZ/pgfplots figure sources (`\input`, no external images) |

Page budget: 13 pages of text + 5 pages of references/appendix, 18 total, per the
S&P CFP. The bundle compiles to exactly 18 pages.

## Overleaf
Upload the flat archive (`YHZ_sp27_source_upload_20261110.zip`): its files sit at
the project root and `main_content_sp27.tex` is the main document. Do not mix this
bundle with the arXiv bundle in one project — Overleaf resolves `\input` from the
project root, so a stray arXiv file with the same name would be picked up instead.
Every input name here is unique to this bundle (`main_preamble`, `main_frontmatter`,
`main_body`, `main_sections/*`, `appendix_sp27`, `submission_references`,
`main_references`, `figures/*`).

## Anonymity note
This bundle is the anonymous-only projection of the internal sources: the
inactive author/ORCID block and the real names in reference [1] were removed
rather than left in `\else` branches, so the archive carries no author identity.
It compiles to the canonical double-blind PDF byte for byte (18 pages,
sha256 `b861c02463d05a8f22fbd9d3af7d0b4e2c8c4941c86f120fa3c1019d3b0d901e`)
